# Advanced Interface Options

## [1.3.4](https://github.com/Stanzilla/AdvancedInterfaceOptions/tree/1.3.4) (2020-01-22)
[Full Changelog](https://github.com/Stanzilla/AdvancedInterfaceOptions/compare/1.3.3...1.3.4)

- incremented retail build number  
- Update FUNDING.yml  
- Update FUNDING.yml  
- Update FUNDING.yml  